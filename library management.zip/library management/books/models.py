from django.db import models
from django.contrib.auth.models import User

class User(User):
    pass
  

class Book(models.Model):
    
    TYPE_CHOICES = (
        ('Drama','Drama'),
        ('Thriller','Thriller'),
        ('Horror', 'Horror'),
        ('Mystery','Mystery'),
        ('Philosophy','Philosophy'),
        ('Crime','Crime'),
    )
    
    book_name = models.CharField(max_length=50)
    pub_name = models.CharField(max_length=50)
    pub_age = models.IntegerField(default=0)
    book_pageno = models.IntegerField(default=0)
    publish_date = models.DateTimeField(default=0)
    type = models.CharField(choices=TYPE_CHOICES, max_length=100, default='Choose')

    def __str__(self):
         return self.book_name

    



    

