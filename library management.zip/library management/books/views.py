from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Book
from .forms import BookForm

def book_list(request):
    books = Book.objects.all()
    context = {
        "books": books
    }
    return render(request, "books/home_page.html", context)

# def book_detail(request, pk):
#     print(pk)
#     return HttpResponse("detailss")

def book_create(request):
    form = BookForm()
    if request.method =="POST":
        form = BookForm(request.POST)
        if form.is_valid():
            # book=form.save()
            # print(book)
            book_name = form.cleaned_data['book_name']
            pub_name = form.cleaned_data['pubisher_name']
            pub_age = form.cleaned_data['pubisher_age']
            book_pageno = form.cleaned_data['book_page_no']
            publish_date = form.cleaned_data['publish_date']

            Book.objects.create(
                book_name = book_name,
                pub_name = pub_name,
                pub_age = pub_age,
                book_pageno = book_pageno,
                publish_date = publish_date
            ).save()
            return redirect('home')
    else:
        context = {
            "form": BookForm()
        }
    return render(request, "books/new_book.html",context)