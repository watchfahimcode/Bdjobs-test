from django import forms

class BookForm(forms.Form):

    book_name = forms.CharField()
    pubisher_name = forms.CharField()
    pubisher_age = forms.IntegerField()
    book_page_no = forms.IntegerField()
    publish_date = forms.DateTimeField()
    # type = forms.CharField(choices=TYPE_CHOICES, max_length=100, default='Choose')